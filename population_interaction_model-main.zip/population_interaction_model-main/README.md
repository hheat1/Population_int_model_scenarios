# population_interaction_model

## lsoa_import
generates the input data needed to run public_transport_synthetic_network.py

## public_transport_synthetic_network
runs a series of MC simulations generating population interaction networks between LSOAs

## how to
open anaconda prompt
navigate to the repository local path using "cd PATH" where PATH is your local repository path, eg, "C:\Workstation\population_interaction_model"
run "python lsoa_import.py"
run "python public_transport_synthetic_network.py"
